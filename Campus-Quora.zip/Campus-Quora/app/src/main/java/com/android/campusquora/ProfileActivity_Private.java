package com.android.campusquora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ProfileActivity_Private extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile__private);
    }
}

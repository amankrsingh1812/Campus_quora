package com.android.campusquora;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.campusquora.model.Post;
import com.bumptech.glide.Glide;
import com.bumptech.glide.annotation.GlideModule;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class PostActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);
        Post post = (Post) getIntent().getSerializableExtra("Post");
        TextView postTitleHeader = findViewById(R.id.post_title_header);
        TextView postContent = findViewById(R.id.post_content);
        postTitleHeader.setText(post.getHeading());
        postContent.setText(post.getText());
        final ImageView postImage = findViewById(R.id.post_image);
        StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("images/"+post.getPostID()+".jpg");
        GlideApp.with(this).load(storageReference).into(postImage);
//        storageReference.getBytes(Long.MAX_VALUE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
//            @Override
//            public void onSuccess(byte[] bytes) {
//                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
//                postImage.setImageBitmap(bitmap);
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(PostActivity.this, "Could not get Image", Toast.LENGTH_SHORT).show();
//            }
//        });
    }
}
